# Contributing

Thanks for considering a contribution.

1. Open an issue first for large features or architectural changes.
2. Keep pull requests focused and explain the user problem they solve.
3. Add or update tests and documentation where behavior changes.
4. Run `npm run test:smoke`, `npm test`, `npm run typecheck`, and `npm run lint` when dependencies are available.
5. Include React Native version, platform, device or simulator, and reproduction steps for platform-specific issues.

By submitting a contribution, you agree that it may be distributed under the project's MIT license.
