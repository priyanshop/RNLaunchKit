import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

const read = (path) => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

test('package defines the supported React Native baseline and core commands', async () => {
  const pkg = JSON.parse(await read('package.json'));
  assert.equal(pkg.dependencies['react-native'], '0.88.0');
  assert.equal(pkg.dependencies.react, '19.3.0');
  assert.equal(pkg.scripts.typecheck, 'tsc --noEmit');
  assert.equal(pkg.scripts.test, 'jest --runInBand');
});

test('app installs query, Redux, navigation, and safe-area providers at the root', async () => {
  const app = await read('App.tsx');
  for (const marker of ['QueryClientProvider', '<Provider', 'NavigationContainer', 'SafeAreaProvider']) {
    assert.ok(app.includes(marker), `missing ${marker}`);
  }
});

test('API config contains no provider secrets and real env files are ignored', async () => {
  const example = await read('src/config/environment.ts');
  const ignore = await read('.gitignore');
  assert.match(example, /API_BASE_URL/);
  assert.doesNotMatch(example, /sk-[A-Za-z0-9]{12,}/);
  assert.match(ignore, /^\.env$/m);
});

test('API client handles non-success responses and empty success responses', async () => {
  const api = await read('src/services/api/client.ts');
  assert.match(api, /if \(!response\.ok\)/);
  assert.match(api, /response\.status === 204/);
  assert.match(api, /schema\.parse\(payload\)/);
});
