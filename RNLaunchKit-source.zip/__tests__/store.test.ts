import {completeOnboarding, setLocale, store} from '../src/state/store';

describe('preferences state', () => {
  beforeEach(() => {
    store.dispatch(setLocale('en'));
  });

  it('starts with onboarding incomplete', () => {
    expect(store.getState().preferences.hasCompletedOnboarding).toBe(false);
  });

  it('stores the selected locale', () => {
    store.dispatch(setLocale('sv'));
    expect(store.getState().preferences.locale).toBe('sv');
  });

  it('marks onboarding as complete', () => {
    store.dispatch(completeOnboarding());
    expect(store.getState().preferences.hasCompletedOnboarding).toBe(true);
  });
});
