# RN LaunchKit

**A practical React Native + TypeScript starting point for production apps.**

LaunchKit gives a new app a small, legible foundation: Hermes-ready React Native, typed navigation, a clear split between server and client state, safe-area handling, API error normalization, a polished sample screen, and CI checks. It is intended to be copied and adapted, not to lock teams into a large framework.

> Status: early public preview. The project has no external adoption or usage metrics yet. Contributions and real-world feedback are welcome.

## What is included

- React Native 0.88 / React 19.3 / TypeScript strict mode
- React Navigation native stack and safe-area provider
- TanStack Query for remote/server state
- Redux Toolkit for small client-only state
- Typed API client with normalized HTTP errors and `204 No Content` support
- Design tokens and a responsive starter home screen
- Smoke checks, Jest setup, and GitHub Actions workflow
- Architecture, setup, security, and contribution notes

The first screen stays intentionally small. Add packages such as Firebase, maps, notifications, charts, localization, or RevenueCat only when a feature needs them; each adds native setup, binary size, and maintenance cost.

## Important: native project shell

This repository contains the LaunchKit application source and configuration. The generated `ios/` and `android/` projects are not checked in yet. Bootstrap those with the official React Native CLI, then copy this repository's source and configuration into the generated app:

```sh
npx @react-native-community/cli@latest init RNLaunchKit --version 0.88.0
```

Use `RNLaunchKit` so the generated native app name matches `app.json`. Keep the generated `ios/` and `android/` directories, replace its `package.json` with this repository's manifest, and copy `App.tsx`, `index.js`, `app.json`, `babel.config.js`, `metro.config.js`, `tsconfig.json`, and `src/`. Then install native support packages using the platform instructions below. This bootstrap step is required because generated native files are coupled to the host's Xcode, Android Gradle, and CocoaPods toolchains.

## Requirements

- Node.js 22 or newer
- Xcode and CocoaPods for iOS builds
- Android Studio, Android SDK, and a JDK supported by the generated Gradle wrapper for Android builds
- A simulator/emulator or physical device

React Native 0.88 uses Hermes by default. Hermes is the JavaScript engine; its startup and memory advantages are useful, but app startup still depends heavily on bundle size, synchronous work, native initialization, and device performance. Measure release builds on representative devices.

## Setup

After bootstrapping the native shell as described above:

```sh
npm install
npm run start
```

In another terminal run `npm run ios` or `npm run android`. The current sample screen does not make an API request, so it works without a backend. Set `API_BASE_URL` in `src/config/environment.ts` before using the API client. Keep secrets out of the mobile app and out of Git.

## Architecture

```text
src/
  config/       environment and build-time configuration
  features/     user-facing feature modules and screens
  services/     network clients and external integrations
  state/        small cross-screen client state
  theme/        shared design tokens
```

Use TanStack Query for values owned by a server: lists, detail records, mutations, caching, and invalidation. Use Redux Toolkit for local, cross-screen state such as onboarding progress or user preferences. Keep ephemeral input and modal state near the component that owns it.

For a feature, keep query keys, schemas, hooks, and UI close to that feature. Pass a Zod schema to `requestJson` so untrusted server responses are checked at the API boundary. Add retries only for idempotent operations and keep mutation retries off unless a request has an idempotency strategy.

## API and AI provider keys

The API client lives in `src/services/api/client.ts`. Configure the base URL for each build environment and add auth headers in one request layer. Never ship OpenAI, Anthropic, Firebase admin, or other private provider credentials in a mobile app: users can extract values from an app bundle. Put provider calls behind a backend you control, enforce authentication and rate limits there, and return a narrow typed response to the app. See [backend guidance](docs/backend.md).

## Quality checks

```sh
npm run test:smoke
npm test
npm run typecheck
npm run lint
```

The smoke suite uses Node's built-in test runner and does not need native tooling. Jest, TypeScript, and lint checks require dependencies to be installed. CI runs the same checks on Node 22.

## Security

Please do not report vulnerabilities in public issues. Read [SECURITY.md](SECURITY.md) for the private disclosure route. Never add credentials, signing certificates, provisioning profiles, or production user data to commits.

## Contributing

Read [CONTRIBUTING.md](CONTRIBUTING.md), open an issue for substantial changes, and include the device/platform and verification steps in pull requests. Small fixes and documentation improvements are welcome.

## License

MIT. See [LICENSE](LICENSE).
