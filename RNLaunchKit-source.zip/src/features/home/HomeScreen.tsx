import React from 'react';
import {ScrollView, StyleSheet, Text, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {colors, spacing} from '../../theme/tokens';

const foundations = [
  {number: '01', title: 'Fast by default', detail: 'Hermes, small entry point, and lazy feature boundaries.'},
  {number: '02', title: 'Typed data flow', detail: 'TanStack Query for server state; Redux Toolkit for app state.'},
  {number: '03', title: 'Native ready', detail: 'React Navigation, safe areas, and platform setup notes.'},
];

export function HomeScreen() {
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.topline}>
          <View style={styles.mark}><Text style={styles.markText}>LK</Text></View>
          <Text style={styles.badge}>OPEN SOURCE STARTER</Text>
        </View>
        <Text style={styles.eyebrow}>SHIP THE FOUNDATION</Text>
        <Text style={styles.title}>Build your next{ '\n' }great app.</Text>
        <Text style={styles.subtitle}>
          A clean React Native + TypeScript foundation built for teams that want to move quickly without inheriting a tangled app.
        </Text>
        <View style={styles.panel}>
          <View style={styles.panelHeader}>
            <View><Text style={styles.panelEyebrow}>PROJECT HEALTH</Text><Text style={styles.panelTitle}>Your launchpad</Text></View>
            <View style={styles.live}><View style={styles.dot}/><Text style={styles.liveText}>READY</Text></View>
          </View>
          <View style={styles.rule}/>
          {foundations.map((item, index) => (
            <View key={item.number} style={[styles.row, index === foundations.length - 1 && styles.lastRow]}>
              <Text style={styles.number}>{item.number}</Text>
              <View style={styles.rowCopy}><Text style={styles.rowTitle}>{item.title}</Text><Text style={styles.rowDetail}>{item.detail}</Text></View>
              <Text style={styles.check}>✓</Text>
            </View>
          ))}
        </View>
        <Text style={styles.footer}>Made for the first commit — and the thousandth.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {flex: 1, backgroundColor: colors.canvas},
  content: {paddingHorizontal: spacing.lg, paddingTop: spacing.md, paddingBottom: spacing.xxl},
  topline: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 56},
  mark: {width: 40, height: 40, borderRadius: 14, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center'},
  markText: {fontSize: 14, fontWeight: '800', color: colors.surface, letterSpacing: 0.4},
  badge: {color: colors.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.1},
  eyebrow: {color: colors.primary, fontSize: 11, fontWeight: '800', letterSpacing: 1.4, marginBottom: 12},
  title: {color: colors.ink, fontSize: 43, lineHeight: 48, fontWeight: '800', letterSpacing: -1.6},
  subtitle: {color: colors.muted, fontSize: 15, lineHeight: 23, marginTop: 16, maxWidth: 450},
  panel: {backgroundColor: colors.surface, borderRadius: 24, padding: spacing.lg, marginTop: 32, borderWidth: 1, borderColor: colors.line},
  panelHeader: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18},
  panelEyebrow: {color: colors.muted, fontSize: 9, fontWeight: '800', letterSpacing: 1.2},
  panelTitle: {color: colors.ink, fontSize: 19, fontWeight: '700', marginTop: 5},
  live: {flexDirection: 'row', alignItems: 'center', backgroundColor: colors.mint, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 99},
  dot: {width: 6, height: 6, borderRadius: 3, backgroundColor: '#15A56A', marginRight: 6},
  liveText: {color: '#16744F', fontSize: 9, fontWeight: '800', letterSpacing: 0.7},
  rule: {height: 1, backgroundColor: colors.line},
  row: {flexDirection: 'row', alignItems: 'center', paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: colors.line},
  lastRow: {borderBottomWidth: 0, paddingBottom: 2},
  number: {color: '#A2AEC1', fontSize: 11, fontWeight: '800', width: 34},
  rowCopy: {flex: 1, paddingRight: 10},
  rowTitle: {color: colors.ink, fontSize: 14, fontWeight: '700'},
  rowDetail: {color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 4},
  check: {color: '#16895E', fontSize: 16, fontWeight: '900'},
  footer: {textAlign: 'center', color: colors.muted, fontSize: 12, marginTop: 24},
});
