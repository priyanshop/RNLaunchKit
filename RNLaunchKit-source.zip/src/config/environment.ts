/** Public app configuration only. Never put private provider credentials here. */
export const API_BASE_URL = 'https://api.example.com';
