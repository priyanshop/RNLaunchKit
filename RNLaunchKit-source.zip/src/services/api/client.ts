import {API_BASE_URL} from '../../config/environment';
import type {z} from 'zod';

export type ApiError = {status: number; message: string; code?: string};

export async function requestJson<T>(path: string, schema: z.ZodType<T>, init: RequestInit = {}): Promise<T> {
  if (API_BASE_URL.includes('example.com')) {
    throw new Error('Set API_BASE_URL in src/config/environment.ts before making API requests.');
  }
  const url = `${API_BASE_URL.replace(/\/$/, '')}/${path.replace(/^\//, '')}`;
  const response = await fetch(url, {
    ...init,
    headers: {'Content-Type': 'application/json', ...init.headers},
  });
  if (!response.ok) {
    const body = await response.json().catch(() => null) as {message?: string; code?: string} | null;
    const error: ApiError = {status: response.status, message: body?.message ?? response.statusText, ...(body?.code ? {code: body.code} : {})};
    throw Object.assign(new Error(error.message), {apiError: error});
  }
  if (response.status === 204) return undefined as T;
  const payload: unknown = await response.json();
  return schema.parse(payload);
}
