export const colors = {
  canvas: '#F5F7FB',
  surface: '#FFFFFF',
  ink: '#15243A',
  muted: '#65748B',
  line: '#E4EAF2',
  primary: '#315CF5',
  primarySoft: '#EAF0FF',
  mint: '#D9F5EA',
  amber: '#FFF0D1',
} as const;

export const spacing = {xs: 6, sm: 10, md: 16, lg: 22, xl: 30, xxl: 40} as const;
