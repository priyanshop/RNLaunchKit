import {configureStore, createSlice, PayloadAction} from '@reduxjs/toolkit';

type PreferencesState = {locale: string; hasCompletedOnboarding: boolean};

const initialState: PreferencesState = {locale: 'en', hasCompletedOnboarding: false};
const preferencesSlice = createSlice({
  name: 'preferences',
  initialState,
  reducers: {
    setLocale(state, action: PayloadAction<string>) { state.locale = action.payload; },
    completeOnboarding(state) { state.hasCompletedOnboarding = true; },
  },
});

export const {setLocale, completeOnboarding} = preferencesSlice.actions;
export const store = configureStore({reducer: {preferences: preferencesSlice.reducer}});
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
