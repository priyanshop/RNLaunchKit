# Security policy

Do not open public issues for suspected vulnerabilities. Use GitHub's private vulnerability reporting for this repository when it is enabled, or contact the maintainer through the public email on their GitHub profile. Include affected versions, impact, and a minimal reproduction. Do not include real user data or live credentials in reports.

This project is an early preview and does not currently promise a response-time SLA.
