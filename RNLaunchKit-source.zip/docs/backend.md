# Backend and AI integration

Mobile code is public to the person who installs it. Treat every value compiled into the app as extractable, including API keys hidden in build settings.

## Request path

```text
React Native app -> authenticated application API -> provider API
```

The app should authenticate with your service using short-lived user credentials. Your server validates the user, enforces quotas and request limits, calls an AI provider with a server-side secret, validates the provider response, and returns a small versioned response shape.

## Example response contract

```ts
export type AssistantReply = {
  id: string;
  text: string;
  createdAt: string;
};
```

Keep provider-specific request and response types on the server. On the app side, validate the public response at the boundary with Zod and expose a typed TanStack Query mutation. Add timeouts, cancellation, user-visible error states, and idempotency for operations that may be retried.

```ts
import {z} from 'zod';

const AssistantReplySchema = z.object({
  id: z.string(),
  text: z.string(),
  createdAt: z.string().datetime(),
});

const reply = await requestJson('/v1/assistant/reply', AssistantReplySchema, {
  method: 'POST',
  body: JSON.stringify({message}),
});
```

## Production checklist

- Keep provider secrets in a server-side secret manager.
- Require user authentication and authorize each resource on the server.
- Add per-user and per-IP quotas, request-size caps, and abuse monitoring.
- Avoid logging prompts or personal data unless there is a clear retention policy.
- Return stable error codes; do not expose raw provider errors or secret configuration.
- Test offline, timeout, rate-limit, and provider-failure cases.
