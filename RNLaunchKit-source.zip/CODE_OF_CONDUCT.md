# Contributor Covenant Code of Conduct

We are committed to a welcoming, respectful, and harassment-free project space for everyone, regardless of experience, identity, background, or viewpoint.

Examples of behavior that contributes to a positive environment include being respectful, giving constructive feedback, accepting differing perspectives, and focusing criticism on ideas rather than people. Harassment, insults, discrimination, unwanted sexual attention, and publishing another person's private information are not acceptable.

Project maintainers may remove, edit, or reject contributions that violate this code and may temporarily or permanently restrict participation. Report issues privately to the project maintainer through the contact information on their GitHub profile.
